/**
 * @file Defines core data and helpers for the WeMote Sports TA NFL Pick Em's Challenge.
 * Includes NFL teams, player pick data, scoring/utility helpers, and CSV/Excel import utilities.
 */

export type PickResult = 'W' | 'L' | 'T' | 'PENDING'

/**
 * Describes a single NFL team with basic metadata and a logo URL.
 */
export interface Team {
  /** Internal identifier (e.g. 'ARI'). */
  id: string
  /** Full team name (e.g. 'Arizona Cardinals'). */
  name: string
  /** Short code used for compact display (e.g. 'ARI'). */
  code: string
  /** Conference name. */
  conference: 'AFC' | 'NFC'
  /** Division within a conference. */
  division: 'East' | 'West' | 'North' | 'South'
  /** Primary brand color (tailwind-friendly). */
  primaryColor: string
  /** Secondary color, used for borders/accents. */
  secondaryColor: string
  /** Logo image URL (must follow the autoimage pattern or a static URL). */
  logoSrc: string
}

/**
 * Represents a pick for a single week.
 */
export interface WeeklyPick {
  /** NFL regular-season week (1–18). */
  week: number
  /** Team identifier; must correspond to a Team.id. */
  teamId: string
  /** Result of the pick: win, loss, tie, or pending. */
  result: PickResult
}

/**
 * Represents a player in the pool and their picks.
 */
export interface Player {
  /** Stable unique ID (slug-safe). */
  id: string
  /** Display name. */
  name: string
  /** All weekly picks the player has made. */
  weeklyPicks: WeeklyPick[]
}

/**
 * Weeks in the regular season (1–18).
 */
export const WEEKS: number[] = Array.from({ length: 18 }, (_, i) => i + 1)

/**
 * Full list of NFL teams used in the challenge.
 * Logos mostly use static URLs; placeholders can be swapped in later if desired.
 */
export const TEAMS: Team[] = [
  {
    id: 'ARI',
    name: 'Arizona Cardinals',
    code: 'ARI',
    conference: 'NFC',
    division: 'West',
    primaryColor: 'bg-red-700',
    secondaryColor: 'border-red-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/8dcbf673-f483-4352-b85c-8e9e5e5648d0.png',
  },
  {
    id: 'ATL',
    name: 'Atlanta Falcons',
    code: 'ATL',
    conference: 'NFC',
    division: 'South',
    primaryColor: 'bg-red-800',
    secondaryColor: 'border-red-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/47f10738-8aa6-4d30-bc34-599861252ef1.png',
  },
  {
    id: 'BAL',
    name: 'Baltimore Ravens',
    code: 'BAL',
    conference: 'AFC',
    division: 'North',
    primaryColor: 'bg-purple-800',
    secondaryColor: 'border-purple-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/0664a451-b99f-494b-a290-6b4219c9dc0a.png',
  },
  {
    id: 'BUF',
    name: 'Buffalo Bills',
    code: 'BUF',
    conference: 'AFC',
    division: 'East',
    primaryColor: 'bg-blue-700',
    secondaryColor: 'border-blue-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/2b475e83-60e2-445c-8d38-82b1003680d6.png',
  },
  {
    id: 'CAR',
    name: 'Carolina Panthers',
    code: 'CAR',
    conference: 'NFC',
    division: 'South',
    primaryColor: 'bg-cyan-700',
    secondaryColor: 'border-cyan-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/1676af78-be75-4672-81aa-45bbd81e07ad.png',
  },
  {
    id: 'CHI',
    name: 'Chicago Bears',
    code: 'CHI',
    conference: 'NFC',
    division: 'North',
    primaryColor: 'bg-blue-900',
    secondaryColor: 'border-orange-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/dbf59a48-f89f-49ca-87fc-1265e8248167.png',
  },
  {
    id: 'CIN',
    name: 'Cincinnati Bengals',
    code: 'CIN',
    conference: 'AFC',
    division: 'North',
    primaryColor: 'bg-orange-600',
    secondaryColor: 'border-orange-300',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/6fd1c536-d150-4ab6-b2b4-fee178144d7b.png',
  },
  {
    id: 'CLE',
    name: 'Cleveland Browns',
    code: 'CLE',
    conference: 'AFC',
    division: 'North',
    primaryColor: 'bg-orange-700',
    secondaryColor: 'border-orange-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/4ec53630-db05-41e0-b6a4-3b976cd06a5c.png',
  },
  {
    id: 'DAL',
    name: 'Dallas Cowboys',
    code: 'DAL',
    conference: 'NFC',
    division: 'East',
    primaryColor: 'bg-slate-800',
    secondaryColor: 'border-slate-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/16c8a827-9fbf-4d05-a82b-369f4e0ca698.png',
  },
  {
    id: 'DEN',
    name: 'Denver Broncos',
    code: 'DEN',
    conference: 'AFC',
    division: 'West',
    primaryColor: 'bg-orange-700',
    secondaryColor: 'border-blue-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/50576dc5-28a0-4610-a176-9f738c14608a.png',
  },
  {
    id: 'DET',
    name: 'Detroit Lions',
    code: 'DET',
    conference: 'NFC',
    division: 'North',
    primaryColor: 'bg-blue-700',
    secondaryColor: 'border-blue-300',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/9f1aca32-d758-4132-9add-6601f812b6f3.png',
  },
  {
    id: 'GB',
    name: 'Green Bay Packers',
    code: 'GB',
    conference: 'NFC',
    division: 'North',
    primaryColor: 'bg-green-800',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/5530af35-142f-4a65-8e45-2188c8d909c1.png',
  },
  {
    id: 'HOU',
    name: 'Houston Texans',
    code: 'HOU',
    conference: 'AFC',
    division: 'South',
    primaryColor: 'bg-slate-900',
    secondaryColor: 'border-red-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/28095ed3-e030-428b-bb13-b19ba158190f.png',
  },
  {
    id: 'IND',
    name: 'Indianapolis Colts',
    code: 'IND',
    conference: 'AFC',
    division: 'South',
    primaryColor: 'bg-blue-800',
    secondaryColor: 'border-blue-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/1f56323b-d740-422d-9c88-116448687c0b.png',
  },
  {
    id: 'JAX',
    name: 'Jacksonville Jaguars',
    code: 'JAX',
    conference: 'AFC',
    division: 'South',
    primaryColor: 'bg-emerald-800',
    secondaryColor: 'border-emerald-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/79306907-13c3-4a31-8467-eb936b0c5c48.png',
  },
  {
    id: 'KC',
    name: 'Kansas City Chiefs',
    code: 'KC',
    conference: 'AFC',
    division: 'West',
    primaryColor: 'bg-red-700',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/a2299152-4487-4b95-8b44-5914fbbd166e.png',
  },
  {
    id: 'LV',
    name: 'Las Vegas Raiders',
    code: 'LV',
    conference: 'AFC',
    division: 'West',
    primaryColor: 'bg-slate-900',
    secondaryColor: 'border-slate-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/8098a71f-8e92-4387-8355-6b7f5af1bd1f.png',
  },
  {
    id: 'LAC',
    name: 'Los Angeles Chargers',
    code: 'LAC',
    conference: 'AFC',
    division: 'West',
    primaryColor: 'bg-sky-700',
    secondaryColor: 'border-sky-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/78828686-817a-47a3-8401-142011cac657.png',
  },
  {
    id: 'LAR',
    name: 'Los Angeles Rams',
    code: 'LAR',
    conference: 'NFC',
    division: 'West',
    primaryColor: 'bg-blue-800',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/cccc7bc0-53c0-45fa-8ab9-12856322bf08.png',
  },
  {
    id: 'MIA',
    name: 'Miami Dolphins',
    code: 'MIA',
    conference: 'AFC',
    division: 'East',
    primaryColor: 'bg-teal-600',
    secondaryColor: 'border-orange-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/eb0e3ce3-7603-4a83-b9f1-50f010cff0c3.png',
  },
  {
    id: 'MIN',
    name: 'Minnesota Vikings',
    code: 'MIN',
    conference: 'NFC',
    division: 'North',
    primaryColor: 'bg-purple-800',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/587a0e15-f9f9-430d-9ad7-9fde6f4a51ab.png',
  },
  {
    id: 'NE',
    name: 'New England Patriots',
    code: 'NE',
    conference: 'AFC',
    division: 'East',
    primaryColor: 'bg-slate-900',
    secondaryColor: 'border-red-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/fad2a4ca-20ef-48f0-a160-5e9dfb6c4c45.png',
  },
  {
    id: 'NO',
    name: 'New Orleans Saints',
    code: 'NO',
    conference: 'NFC',
    division: 'South',
    primaryColor: 'bg-zinc-800',
    secondaryColor: 'border-yellow-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/2f76ca20-a8fb-47ab-b23f-328cd42d2cdd.png',
  },
  {
    id: 'NYG',
    name: 'New York Giants',
    code: 'NYG',
    conference: 'NFC',
    division: 'East',
    primaryColor: 'bg-blue-800',
    secondaryColor: 'border-red-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/18252a14-cef0-4c3b-ac80-0249c0552fa8.png',
  },
  {
    id: 'NYJ',
    name: 'New York Jets',
    code: 'NYJ',
    conference: 'AFC',
    division: 'East',
    primaryColor: 'bg-emerald-800',
    secondaryColor: 'border-emerald-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/aaaec623-de8b-445d-a96f-ef61a220a4b9.png',
  },
  {
    id: 'PHI',
    name: 'Philadelphia Eagles',
    code: 'PHI',
    conference: 'NFC',
    division: 'East',
    primaryColor: 'bg-emerald-800',
    secondaryColor: 'border-emerald-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/26ce2205-0002-4f14-a93b-b13b1b43bae0.png',
  },
  {
    id: 'PIT',
    name: 'Pittsburgh Steelers',
    code: 'PIT',
    conference: 'AFC',
    division: 'North',
    primaryColor: 'bg-slate-900',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/834170cf-f892-42bc-8581-81843bc4a9bb.png',
  },
  {
    id: 'SEA',
    name: 'Seattle Seahawks',
    code: 'SEA',
    conference: 'NFC',
    division: 'West',
    primaryColor: 'bg-slate-900',
    secondaryColor: 'border-lime-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/a2c162e0-5ec2-4193-84e7-830ca00f9f99.png',
  },
  {
    id: 'SF',
    name: 'San Francisco 49ers',
    code: 'SF',
    conference: 'NFC',
    division: 'West',
    primaryColor: 'bg-red-700',
    secondaryColor: 'border-yellow-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/126746df-e367-4bd2-8def-425ebf5e957a.png',
  },
  {
    id: 'TB',
    name: 'Tampa Bay Buccaneers',
    code: 'TB',
    conference: 'NFC',
    division: 'South',
    primaryColor: 'bg-red-800',
    secondaryColor: 'border-gray-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/56212dbf-d9ce-43f8-80d1-10c8c27c58e9.png',
  },
  {
    id: 'TEN',
    name: 'Tennessee Titans',
    code: 'TEN',
    conference: 'AFC',
    division: 'South',
    primaryColor: 'bg-sky-800',
    secondaryColor: 'border-sky-400',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/9c431849-3d4f-40ef-8f10-f514839c6c22.png',
  },
  {
    id: 'WAS',
    name: 'Washington Commanders',
    code: 'WAS',
    conference: 'NFC',
    division: 'East',
    primaryColor: 'bg-amber-900',
    secondaryColor: 'border-amber-500',
    logoSrc:
      'https://pub-cdn.sider.ai/u/U05XHKL2G8/web-coder/692f5eec3504a6c92323ac5f/resource/dc21fa6c-5339-491d-969f-87a241e71c76.png',
  },
]

/**
 * Quick lookup map from team ID to the Team object.
 */
export const TEAMS_BY_ID: Record<string, Team> = TEAMS.reduce(
  (acc, team) => {
    acc[team.id] = team
    return acc
  },
  {} as Record<string, Team>,
)

/**
 * Internal helper to create a weekly pick.
 */
const wp = (week: number, teamId: string, result: PickResult): WeeklyPick => ({
  week,
  teamId,
  result,
})

/**
 * Core list of all players and their picks.
 *
 * NOTE: Includes weeks 1–14 parsed from your spreadsheet plus Week 15 picks
 * (marked as PENDING / not yet played).
 */
export const PLAYERS: Player[] = [
  {
    id: 'alexa',
    name: 'Alexa',
    weeklyPicks: [
      wp(1, 'MIA', 'L'),
      wp(2, 'BUF', 'W'),
      wp(3, 'WAS', 'W'),
      wp(4, 'PIT', 'W'),
      wp(5, 'KC', 'L'),
      wp(6, 'SF', 'L'),
      wp(7, 'CIN', 'W'),
      wp(8, 'DAL', 'L'),
      wp(9, 'BAL', 'W'),
      wp(10, 'LV', 'L'),
      wp(11, 'NE', 'W'),
      wp(12, 'CAR', 'L'),
      wp(13, 'IND', 'L'),
      wp(14, 'GB', 'W'),
      wp(15, 'ARI', 'L'),
      wp(16, 'LAR', 'L'),
      wp(17, 'SEA', 'W'),
      wp(18, 'NYJ', 'PENDING'),
    ],
  },
  {
    id: 'ali',
    name: 'Ali',
    weeklyPicks: [
      wp(1, 'PIT', 'W'),
      wp(2, 'ARI', 'W'),
      wp(3, 'IND', 'W'),
      wp(4, 'BUF', 'W'),
      wp(5, 'PHI', 'L'),
      wp(6, 'DAL', 'L'),
      wp(7, 'NE', 'W'),
      wp(8, 'ATL', 'L'),
      wp(9, 'DET', 'L'),
      wp(10, 'SEA', 'W'),
      wp(11, 'LAC', 'L'),
      wp(12, 'BAL', 'W'),
      wp(13, 'SF', 'W'),
      wp(14, 'TB', 'L'),
      wp(15, 'CAR', 'L'),
      wp(16, 'NO', 'W'),
      wp(17, 'CIN', 'W'),
      wp(18, 'KC', 'PENDING'),
    ],
  },
  {
    id: 'ann',
    name: 'Ann',
    weeklyPicks: [
      wp(1, 'GB', 'W'),
      wp(2, 'ARI', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'NE', 'W'),
      wp(5, 'PHI', 'L'),
      wp(6, 'WAS', 'L'),
      wp(7, 'CAR', 'W'),
      wp(8, 'IND', 'W'),
      wp(9, 'BAL', 'W'),
      wp(10, 'LAR', 'W'),
      wp(11, 'TB', 'L'),
      wp(12, 'SF', 'W'),
      wp(13, 'DEN', 'W'),
      wp(14, 'BUF', 'W'),
      wp(15, 'CIN', 'L'),
      wp(16, 'LAC', 'W'),
      wp(17, 'CHI', 'L'),
      wp(18, 'DAL', 'PENDING'),
    ],
  },
  {
    id: 'ari',
    name: 'Ari',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'PIT', 'W'),
      wp(4, 'DET', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'DEN', 'W'),
      wp(7, 'GB', 'W'),
      wp(8, 'ATL', 'L'),
      wp(9, 'LAC', 'W'),
      wp(10, 'SEA', 'W'),
      wp(11, 'HOU', 'W'),
      wp(12, 'SF', 'W'),
      wp(13, 'JAX', 'W'),
      wp(14, 'TB', 'L'),
      wp(15, 'LAR', 'W'),
      wp(16, 'BUF', 'W'),
      wp(17, 'CIN', 'W'),
      wp(18, 'NE', 'PENDING'),
    ],
  },
  {
    id: 'bill',
    name: 'Bill',
    weeklyPicks: [
      wp(1, 'CIN', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'BUF', 'W'),
      wp(4, 'DET', 'W'),
      wp(5, 'PHI', 'L'),
      wp(6, 'NE', 'W'),
      wp(7, 'PIT', 'L'),
      wp(8, 'IND', 'W'),
      wp(9, 'LAR', 'W'),
      wp(10, 'CAR', 'L'),
      wp(11, 'MIN', 'L'),
      wp(12, 'BAL', 'W'),
      wp(13, 'JAX', 'W'),
      wp(14, 'NYJ', 'L'),
      wp(15, 'SEA', 'W'),
      wp(16, 'DEN', 'L'),
      wp(17, 'TEN', 'L'),
      wp(18, 'SF', 'PENDING'),
    ],
  },
  {
    id: 'halligan',
    name: 'Halligan',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'PIT', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'PHI', 'L'),
      wp(7, 'CLE', 'W'),
      wp(8, 'SF', 'L'),
      wp(9, 'GB', 'L'),
      wp(10, 'MIN', 'L'),
      wp(11, 'CAR', 'W'),
      wp(12, 'JAX', 'W'),
      wp(13, 'BAL', 'L'),
      wp(14, 'BUF', 'W'),
      wp(15, 'NE', 'L'),
      wp(16, 'NYJ', 'L'),
      wp(17, 'MIA', 'W'),
      wp(18, 'CAR', 'PENDING'),
    ],
  },
  {
    id: 'smeal',
    name: 'Smeal',
    weeklyPicks: [
      wp(1, 'TEN', 'L'),
      wp(2, 'BAL', 'W'),
      wp(3, 'GB', 'L'),
      wp(4, 'SF', 'L'),
      wp(5, 'ARI', 'L'),
      wp(6, 'PIT', 'W'),
      wp(7, 'NO', 'L'),
      wp(8, 'MIA', 'W'),
      wp(9, 'DAL', 'L'),
      wp(10, 'ATL', 'L'),
      wp(11, 'NYJ', 'L'),
      wp(12, 'LV', 'L'),
      wp(13, 'PHI', 'L'),
      wp(14, 'LAC', 'W'),
      wp(15, 'CLE', 'L'),
      wp(16, 'MIN', 'W'),
      wp(17, 'NE', 'W'),
      wp(18, 'DET', 'PENDING'),
    ],
  },
  {
    id: 'dave',
    name: 'Dave',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'LAR', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'NE', 'W'),
      wp(5, 'KC', 'L'),
      wp(6, 'PHI', 'L'),
      wp(7, 'GB', 'W'),
      wp(8, 'TB', 'W'),
      wp(9, 'DAL', 'L'),
      wp(10, 'IND', 'W'),
      wp(11, 'BAL', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'MIA', 'W'),
      wp(14, 'LAC', 'W'),
      wp(15, 'PIT', 'W'),
      wp(16, 'HOU', 'W'),
      wp(17, 'DEN', 'W'),
      wp(18, 'JAX', 'PENDING'),
    ],
  },
  {
    id: 'farzana',
    name: 'Farzana',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'BUF', 'W'),
      wp(3, 'TB', 'W'),
      wp(4, 'DET', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'DEN', 'W'),
      wp(7, 'NE', 'W'),
      wp(8, 'CIN', 'L'),
      wp(9, 'GB', 'L'),
      wp(10, 'CAR', 'L'),
      wp(11, 'SF', 'W'),
      wp(12, 'BAL', 'W'),
      wp(13, 'LAC', 'W'),
      wp(14, 'LAR', 'W'),
      wp(15, 'HOU', 'W'),
      wp(16, 'PHI', 'W'),
      wp(17, 'SEA', 'W'),
      wp(18, 'JAX', 'PENDING'),
    ],
  },
  {
    id: 'greg',
    name: 'Greg',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'SF', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'PIT', 'W'),
      wp(5, 'MIN', 'W'),
      wp(6, 'LAC', 'W'),
      wp(7, 'NE', 'W'),
      wp(8, 'CIN', 'L'),
      wp(9, 'CHI', 'W'),
      wp(10, 'BUF', 'L'),
      wp(11, 'BAL', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'JAX', 'W'),
      wp(14, 'DEN', 'W'),
      wp(15, 'PHI', 'W'),
      wp(16, 'HOU', 'W'),
      wp(17, 'DAL', 'W'),
      wp(18, 'LAR', 'PENDING'),
    ],
  },
  {
    id: 'james',
    name: 'James',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'SF', 'W'),
      wp(3, 'GB', 'L'),
      wp(4, 'WAS', 'L'),
      wp(5, 'DAL', 'W'),
      wp(6, 'NE', 'W'),
      wp(7, 'PIT', 'L'),
      wp(8, 'IND', 'W'),
      wp(9, 'DEN', 'W'),
      wp(10, 'DET', 'W'),
      wp(11, 'HOU', 'W'),
      wp(12, 'SEA', 'W'),
      wp(13, 'JAX', 'W'),
      wp(14, 'CLE', 'L'),
      wp(15, 'CHI', 'W'),
      wp(16, 'BUF', 'W'),
      wp(17, 'NYG', 'W'),
      wp(18, 'PHI', 'PENDING'),
    ],
  },
  {
    id: 'jazmine',
    name: 'Jazmine',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'CIN', 'W'),
      wp(3, 'GB', 'L'),
      wp(4, 'DET', 'W'),
      wp(5, 'BUF', 'L'),
      wp(6, 'DEN', 'W'),
      wp(7, 'KC', 'W'),
      wp(8, 'IND', 'W'),
      wp(9, 'LAC', 'W'),
      wp(10, 'SEA', 'W'),
      wp(11, 'NE', 'W'),
      wp(12, 'SF', 'W'),
      wp(13, 'TB', 'W'),
      wp(14, 'CLE', 'L'),
      wp(15, 'PHI', 'W'),
      wp(16, 'HOU', 'W'),
      wp(17, 'DAL', 'W'),
      wp(18, 'JAX', 'PENDING'),
    ],
  },
  {
    id: 'jc',
    name: 'JC',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'HOU', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'LV', 'W'),
      wp(7, 'CHI', 'W'),
      wp(8, 'CIN', 'L'),
      wp(9, 'BAL', 'W'),
      wp(10, 'CAR', 'L'),
      wp(11, 'GB', 'W'),
      wp(12, 'SF', 'W'),
      wp(13, 'LAR', 'L'),
      wp(14, 'TB', 'L'),
      wp(15, 'JAX', 'W'),
      wp(16, 'PHI', 'W'),
      wp(17, 'NE', 'W'),
      wp(18, 'BUF', 'PENDING'),
    ],
  },
  {
    id: 'justin',
    name: 'Justin',
    weeklyPicks: [
      wp(1, 'DEN', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'HOU', 'W'),
      wp(5, 'ARI', 'L'),
      wp(6, 'PHI', 'L'),
      wp(7, 'NE', 'W'),
      wp(8, 'IND', 'W'),
      wp(9, 'LAC', 'W'),
      wp(10, 'DET', 'W'),
      wp(11, 'PIT', 'W'),
      wp(12, 'GB', 'W'),
      wp(13, 'MIA', 'W'),
      wp(14, 'BAL', 'L'),
      wp(15, 'JAX', 'W'),
      wp(16, 'SF', 'W'),
      wp(17, 'LAR', 'PENDING'),
      wp(18, 'CIN', 'PENDING'),
    ],
  },
  {
    id: 'katherine',
    name: 'Katherine',
    weeklyPicks: [
      wp(1, 'WAS', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'LAC', 'L'),
      wp(5, 'BUF', 'L'),
      wp(6, 'NE', 'W'),
      wp(7, 'CHI', 'W'),
      wp(8, 'TB', 'W'),
      wp(9, 'LAR', 'W'),
      wp(10, 'DEN', 'W'),
      wp(11, 'HOU', 'W'),
      wp(12, 'GB', 'W'),
      wp(13, 'JAX', 'W'),
      wp(14, 'SEA', 'W'),
      wp(15, 'SF', 'W'),
      wp(16, 'KC', 'L'),
      wp(17, 'PIT', 'L'),
      wp(18, 'PHI', 'PENDING'),
    ],
  },
  {
    id: 'katie',
    name: 'Katie',
    weeklyPicks: [
      wp(1, 'GB', 'W'),
      wp(2, 'BUF', 'W'),
      wp(3, 'DAL', 'L'),
      wp(4, 'LAC', 'L'),
      wp(5, 'DET', 'W'),
      wp(6, 'DEN', 'W'),
      wp(7, 'SEA', 'W'),
      wp(8, 'NE', 'W'),
      wp(9, 'LAR', 'W'),
      wp(10, 'IND', 'W'),
      wp(11, 'SF', 'W'),
      wp(12, 'BAL', 'W'),
      wp(13, 'PHI', 'L'),
      wp(14, 'NO', 'W'),
      wp(15, 'HOU', 'W'),
      wp(16, 'CHI', 'W'),
      wp(17, 'PIT', 'L'),
      wp(18, 'CIN', 'PENDING'),
    ],
  },
  {
    id: 'lacey',
    name: 'Lacey',
    weeklyPicks: [
      wp(1, 'DEN', 'W'),
      wp(2, 'ARI', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'HOU', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'PIT', 'W'),
      wp(7, 'CHI', 'W'),
      wp(8, 'NE', 'W'),
      wp(9, 'GB', 'L'),
      wp(10, 'BUF', 'L'),
      wp(11, 'BAL', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'LAC', 'W'),
      wp(14, 'TB', 'L'),
      wp(15, 'PHI', 'W'),
      wp(16, 'KC', 'L'),
      wp(17, 'LAR', 'PENDING'),
      wp(18, 'SEA', 'PENDING'),
    ],
  },
  {
    id: 'schulman',
    name: 'Schulman',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'PIT', 'L'),
      wp(3, 'DAL', 'L'),
      wp(4, 'LAC', 'L'),
      wp(5, 'LAR', 'L'),
      wp(6, 'IND', 'W'),
      wp(7, 'DEN', 'W'),
      wp(8, 'PHI', 'W'),
      wp(9, 'CIN', 'L'),
      wp(10, 'NYJ', 'W'),
      wp(11, 'MIA', 'W'),
      wp(12, 'SEA', 'W'),
      wp(13, 'NE', 'W'),
      wp(14, 'KC', 'L'),
      wp(15, 'TB', 'L'),
      wp(16, 'HOU', 'W'),
      wp(17, 'JAX', 'W'),
      wp(18, 'GB', 'PENDING'),
    ],
  },
  {
    id: 'farrar',
    name: 'Farrar',
    weeklyPicks: [
      wp(1, 'MIA', 'L'),
      wp(2, 'CIN', 'W'),
      wp(3, 'TB', 'W'),
      wp(4, 'HOU', 'W'),
      wp(5, 'ARI', 'L'),
      wp(6, 'DAL', 'L'),
      wp(7, 'KC', 'W'),
      wp(8, 'IND', 'W'),
      wp(9, 'LAR', 'W'),
      wp(10, 'CHI', 'W'),
      wp(11, 'NE', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'PHI', 'L'),
      wp(14, 'DEN', 'W'),
      wp(15, 'JAX', 'W'),
      wp(16, 'BUF', 'W'),
      wp(17, 'SEA', 'W'),
      wp(18, 'GB', 'PENDING'),
    ],
  },
  {
    id: 'morgann',
    name: 'Morgann',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'BAL', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'BUF', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'GB', 'W'),
      wp(7, 'NE', 'W'),
      wp(8, 'ATL', 'L'),
      wp(9, 'LAC', 'W'),
      wp(10, 'DEN', 'W'),
      wp(11, 'HOU', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'SF', 'W'),
      wp(14, 'TB', 'L'),
      wp(15, 'JAX', 'W'),
      wp(16, 'PHI', 'W'),
      wp(17, 'LAR', 'PENDING'),
      wp(18, 'DAL', 'PENDING'),
    ],
  },
  {
    id: 'nathan',
    name: 'Nathan',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'LAR', 'W'),
      wp(3, 'TB', 'W'),
      wp(4, 'BUF', 'W'),
      wp(5, 'DET', 'W'),
      wp(6, 'WAS', 'L'),
      wp(7, 'GB', 'W'),
      wp(8, 'PHI', 'W'),
      wp(9, 'IND', 'L'),
      wp(10, 'DEN', 'W'),
      wp(11, 'LAC', 'L'),
      wp(12, 'KC', 'W'),
      wp(13, 'NO', 'L'),
      wp(14, 'BAL', 'L'),
      wp(15, 'HOU', 'W'),
      wp(16, 'JAX', 'W'),
      wp(17, 'CHI', 'L'),
      wp(18, 'SEA', 'PENDING'),
    ],
  },
  {
    id: 'paul',
    name: 'Paul',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'ATL', 'L'),
      wp(4, 'HOU', 'W'),
      wp(5, 'IND', 'W'),
      wp(6, 'PIT', 'W'),
      wp(7, 'NE', 'W'),
      wp(8, 'CIN', 'L'),
      wp(9, 'GB', 'L'),
      wp(10, 'DET', 'W'),
      wp(11, 'BAL', 'W'),
      wp(12, 'SEA', 'W'),
      wp(13, 'SF', 'W'),
      wp(14, 'TB', 'L'),
      wp(15, 'JAX', 'W'),
      wp(16, 'PHI', 'W'),
      wp(17, 'LAR', 'PENDING'),
      wp(18, 'BUF', 'PENDING'),
    ],
  },
  {
    id: 'phil',
    name: 'Phil',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DEN', 'L'),
      wp(3, 'IND', 'W'),
      wp(4, 'WAS', 'L'),
      wp(5, 'PHI', 'L'),
      wp(6, 'NE', 'W'),
      wp(7, 'CAR', 'W'),
      wp(8, 'BUF', 'W'),
      wp(9, 'DAL', 'L'),
      wp(10, 'MIN', 'L'),
      wp(11, 'BAL', 'W'),
      wp(12, 'DET', 'W'),
      wp(13, 'LAC', 'W'),
      wp(14, 'LAR', 'W'),
      wp(15, 'CHI', 'W'),
      wp(16, 'HOU', 'W'),
      wp(17, 'PIT', 'L'),
      wp(18, 'SEA', 'PENDING'),
    ],
  },
  {
    id: 'rachel',
    name: 'Rachel',
    weeklyPicks: [
      wp(1, 'LAR', 'W'),
      wp(2, 'PIT', 'L'),
      wp(3, 'WAS', 'W'),
      wp(4, 'TEN', 'L'),
      wp(5, 'LV', 'L'),
      wp(6, 'PHI', 'L'),
      wp(7, 'CLE', 'W'),
      wp(8, 'SF', 'L'),
      wp(9, 'LAC', 'W'),
      wp(10, 'IND', 'W'),
      wp(11, 'GB', 'W'),
      wp(12, 'NE', 'W'),
      wp(13, 'KC', 'L'),
      wp(14, 'SEA', 'W'),
      wp(15, 'HOU', 'W'),
      wp(16, 'MIN', 'W'),
      wp(17, 'BAL', 'W'),
      wp(18, 'DAL', 'PENDING'),
    ],
  },
  {
    id: 'stephanie',
    name: 'Stephanie',
    weeklyPicks: [
      wp(1, 'ARI', 'W'),
      wp(2, 'DAL', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'HOU', 'W'),
      wp(5, 'MIN', 'W'),
      wp(6, 'LAC', 'W'),
      wp(7, 'NE', 'W'),
      wp(8, 'SF', 'L'),
      wp(9, 'LAR', 'W'),
      wp(10, 'DEN', 'W'),
      wp(11, 'GB', 'W'),
      wp(12, 'BAL', 'W'),
      wp(13, 'IND', 'L'),
      wp(14, 'TB', 'L'),
      wp(15, 'JAX', 'W'),
      wp(16, 'PHI', 'W'),
      wp(17, 'DET', 'L'),
      wp(18, 'BUF', 'PENDING'),
    ],
  },
  {
    id: 'zack',
    name: 'Zack',
    weeklyPicks: [
      wp(1, 'LV', 'W'),
      wp(2, 'NE', 'W'),
      wp(3, 'SEA', 'W'),
      wp(4, 'CHI', 'W'),
      wp(5, 'NYG', 'L'),
      wp(6, 'DAL', 'L'),
      wp(7, 'PHI', 'W'),
      wp(8, 'SF', 'L'),
      wp(9, 'ARI', 'W'),
      wp(10, 'GB', 'L'),
      wp(11, 'KC', 'L'),
      wp(12, 'BUF', 'L'),
      wp(13, 'TB', 'W'),
      wp(14, 'TEN', 'W'),
      wp(15, 'JAX', 'W'),
      wp(16, 'HOU', 'W'),
      wp(17, 'DEN', 'W'),
      wp(18, 'LAC', 'PENDING'),
    ],
  },
]

/**
 * Computes the per-week point value for a correct pick,
 * based on the league's scoring bands.
 */
export const getPointsForWeek = (week: number): number => {
  if (week >= 1 && week <= 4) return 2
  if (week >= 5 && week <= 8) return 4
  if (week >= 9 && week <= 13) return 6
  return 8
}

/**
 * Computes the total points a player has earned across all their picks.
 * Wins give full points for that week; ties give half that week's points.
 */
export const getPlayerTotalPoints = (player: Player): number =>
  player.weeklyPicks.reduce((total, pick) => {
    const base = getPointsForWeek(pick.week)
    if (pick.result === 'W') {
      return total + base
    }
    if (pick.result === 'T') {
      return total + base / 2
    }
    return total
  }, 0)

/**
 * Returns the set of team IDs that a player has already picked at least once.
 */
export const getTeamsUsedByPlayer = (player: Player): Set<string> => {
  const used = new Set<string>()
  player.weeklyPicks.forEach((p) => {
    used.add(p.teamId)
  })
  return used
}

/**
 * Returns all teams that the player can still pick (never used so far).
 */
export const getTeamsLeftForPlayer = (player: Player): Team[] => {
  const used = getTeamsUsedByPlayer(player)
  return TEAMS.filter((team) => !used.has(team.id))
}

/**
 * Convenience helper: sorts players by descending total points,
 * breaking ties alphabetically by name.
 */
export const getPlayersSortedByPoints = (players: Player[]): Player[] => {
  return [...players].sort((a, b) => {
    const diff = getPlayerTotalPoints(b) - getPlayerTotalPoints(a)
    if (diff !== 0) return diff
    return a.name.localeCompare(b.name)
  })
}

/* ========================================================================== */
/*                          CSV / EXCEL IMPORT HELPERS                        */
/* ========================================================================== */

/**
 * Row format for long-form (one pick per row) imported data.
 */
export interface RawLongFormRow {
  /** Player name (as shown in Excel). */
  player: string
  /** Week number (1–18). */
  week: number
  /** Team name or code (e.g. "Greenbay Packers" or "GB"). */
  team: string
  /** Result string that will be normalized into PickResult. */
  result: string
}

/**
 * Normalizes a team key by lowercasing and stripping non-letters.
 * Used to match messy Excel names against canonical team names/codes.
 */
export const normalizeTeamKey = (value: string): string =>
  value.toLowerCase().replace(/[^a-z]/g, '')

/**
 * Precomputed lookup from normalized team key to canonical team ID.
 * Keys include:
 * - Normalized full team name (e.g. "greenbaypackers")
 * - Normalized code (e.g. "gb")
 * - A few manual synonyms that match your spreadsheet (e.g. "pittsburgsteelers").
 */
const TEAM_KEY_TO_ID: Record<string, string> = (() => {
  const map: Record<string, string> = {}

  TEAMS.forEach((team) => {
    const nameKey = normalizeTeamKey(team.name)
    const codeKey = normalizeTeamKey(team.code)

    map[nameKey] = team.id
    map[codeKey] = team.id
  })

  // Manual synonyms / common spreadsheet variants.
  map[normalizeTeamKey('Pittsburg Steelers')] = 'PIT'
  map[normalizeTeamKey('San Francisco')] = 'SF'

  return map
})()

/**
 * Attempts to resolve a free-form team name/code to a canonical team ID.
 * Returns undefined if no reasonable match is found.
 */
export const lookupTeamId = (value: string): string | undefined => {
  const key = normalizeTeamKey(value)
  if (!key) return undefined
  return TEAM_KEY_TO_ID[key]
}

/**
 * Normalizes a raw result string into the PickResult union.
 * Accepts values like: "W", "WIN", "L", "LOSS", "T", "TIE", "P", "PENDING", "".
 */
export const normalizeResult = (value: string): PickResult => {
  const v = value.trim().toLowerCase()
  if (v === 'w' || v === 'win' || v === 'wins') return 'W'
  if (v === 'l' || v === 'loss' || v === 'lose' || v === 'lost') return 'L'
  if (v === 't' || v === 'tie' || v === 'ties') return 'T'
  if (v === 'p' || v === 'pending' || v === '') return 'PENDING'
  // Fallback: treat unknown as pending so it is visually distinct.
  return 'PENDING'
}

/**
 * Simple slugifier for deriving a stable player ID from a display name.
 */
export const slugifyPlayerId = (name: string): string => {
  const slug = name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return slug || 'player'
}

/**
 * Parses a long-form CSV/TSV string into raw rows.
 *
 * Expected columns (header row, order flexible):
 * - "player" or "name"
 * - "week"
 * - "team" or "pick" or "teamname"
 * - "result" or "w/l" or "outcome"
 *
 * The function auto-detects comma vs tab separators and ignores blank lines.
 */
export const parseLongFormPicks = (raw: string): RawLongFormRow[] => {
  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0)

  if (lines.length === 0) return []

  const firstLine = lines[0]
  const delimiter = firstLine.includes('\t') ? '\t' : ','

  const headerCells = firstLine.split(delimiter).map((h) => h.trim().toLowerCase())

  const colPlayer =
    headerCells.findIndex((h) => h === 'player' || h === 'name') ?? 0
  const colWeek = headerCells.findIndex((h) => h === 'week')
  const colTeam =
    headerCells.findIndex(
      (h) => h === 'team' || h === 'pick' || h === 'teamname',
    ) ?? 2
  const colResult =
    headerCells.findIndex(
      (h) => h === 'result' || h === 'w/l' || h === 'outcome',
    ) ?? 3

  const hasHeaderWeek = colWeek !== -1
  const startIndex = hasHeaderWeek ? 1 : 0

  const rows: RawLongFormRow[] = []

  for (let i = startIndex; i < lines.length; i += 1) {
    const line = lines[i]
    if (!line) continue
    const cells = line.split(delimiter)

    const player = (cells[colPlayer] ?? '').trim()
    const weekRaw = colWeek !== -1 ? cells[colWeek] ?? '' : cells[1] ?? ''
    const team = (cells[colTeam] ?? '').trim()
    const result = (cells[colResult] ?? '').trim()

    const week = Number.parseInt(weekRaw, 10)
    if (!player || !team || Number.isNaN(week) || week < 1 || week > 18) {
      // Skip malformed lines rather than throwing; caller can log if needed.
      // eslint-disable-next-line no-continue
      continue
    }

    rows.push({ player, week, team, result })
  }

  return rows
}

/**
 * Builds Player objects (with WeeklyPick arrays) from long-form rows.
 * Players are keyed by their name; weeks are deduplicated and sorted.
 */
export const buildPlayersFromLongForm = (rows: RawLongFormRow[]): Player[] => {
  const byName = new Map<string, Player>()

  rows.forEach((row) => {
    const name = row.player.trim()
    if (!name) return

    const id = slugifyPlayerId(name)
    let player = byName.get(name)

    if (!player) {
      player = { id, name, weeklyPicks: [] }
      byName.set(name, player)
    }

    const teamId = lookupTeamId(row.team)
    if (!teamId) {
      // If we cannot resolve the team, skip this pick; this is safer than
      // inserting an invalid teamId and causing downstream issues.
      return
    }

    const normalizedResult = normalizeResult(row.result)

    // Replace any existing pick for this week for this player.
    const existingIndex = player.weeklyPicks.findIndex((p) => p.week === row.week)
    const newPick: WeeklyPick = {
      week: row.week,
      teamId,
      result: normalizedResult,
    }

    if (existingIndex >= 0) {
      player.weeklyPicks[existingIndex] = newPick
    } else {
      player.weeklyPicks.push(newPick)
    }
  })

  // Sort weekly picks for each player by week.
  const players = Array.from(byName.values())
  players.forEach((p) => {
    p.weeklyPicks.sort((a, b) => a.week - b.week)
  })

  return players
}

/**
 * Merges a base players list with an imported players list.
 *
 * - Players are matched by name (case-insensitive).
 * - For overlapping weeks, imported picks override base picks.
 * - Players that exist only in imported data are appended.
 */
export const mergePlayers = (base: Player[], imported: Player[]): Player[] => {
  const result: Player[] = []

  const importedByName = new Map<string, Player>()
  imported.forEach((p) => {
    importedByName.set(p.name.toLowerCase(), p)
  })

  base.forEach((basePlayer) => {
    const key = basePlayer.name.toLowerCase()
    const importedPlayer = importedByName.get(key)

    if (!importedPlayer) {
      result.push(basePlayer)
      return
    }

    const byWeek = new Map<number, WeeklyPick>()
    basePlayer.weeklyPicks.forEach((pick) => {
      byWeek.set(pick.week, pick)
    })
    importedPlayer.weeklyPicks.forEach((pick) => {
      // Imported data overrides the base for a given week.
      byWeek.set(pick.week, pick)
    })

    const mergedPicks = Array.from(byWeek.values()).sort(
      (a, b) => a.week - b.week,
    )

    result.push({
      ...basePlayer,
      weeklyPicks: mergedPicks,
    })

    importedByName.delete(key)
  })

  // Add remaining imported-only players.
  importedByName.forEach((player) => {
    result.push(player)
  })

  return result
}