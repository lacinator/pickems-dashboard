/**
 * @file Aggregated team statistics helpers for the NFL Pick Em's challenge.
 * Builds summary metrics (picks, wins, losses, win rate) for each NFL team.
 */

import { PLAYERS, type Player, type Team, type WeeklyPick, TEAMS } from './pickems'

/**
 * Aggregated statistics for a single NFL team across all players and weeks.
 */
export interface TeamStats {
  /** Team metadata object. */
  team: Team
  /** Total number of non-pending picks made for this team. */
  picks: number
  /** Number of winning picks for this team. */
  wins: number
  /** Number of losing picks for this team. */
  losses: number
  /** Win percentage as a 0–1 fraction (wins / (wins + losses)). */
  winRate: number
}

/**
 * Internal accumulator used while computing team stats.
 */
interface TeamStatsAccumulator {
  team: Team
  picks: number
  wins: number
  losses: number
}

/**
 * Updates an accumulator object with a single weekly pick.
 *
 * @param acc - Mutable accumulator for one team.
 * @param pick - Weekly pick to apply.
 */
const applyPickToAccumulator = (acc: TeamStatsAccumulator, pick: WeeklyPick): void => {
  if (pick.result === 'PENDING') {
    // Pending results are ignored for win/loss statistics.
    return
  }

  acc.picks += 1
  if (pick.result === 'W') {
    acc.wins += 1
  } else if (pick.result === 'L') {
    acc.losses += 1
  }
}

/**
 * Computes aggregated statistics for every team given a list of players.
 *
 * @param players - Players whose picks should be included. Defaults to the global PLAYERS list.
 * @returns Sorted array of TeamStats, ordered by descending number of picks.
 */
export const computeTeamStats = (players: Player[] = PLAYERS): TeamStats[] => {
  const byId = new Map<string, TeamStatsAccumulator>()

  // Ensure every team exists in the map, even if it has zero picks.
  TEAMS.forEach((team) => {
    byId.set(team.id, {
      team,
      picks: 0,
      wins: 0,
      losses: 0,
    })
  })

  players.forEach((player) => {
    player.weeklyPicks.forEach((pick) => {
      const acc = byId.get(pick.teamId)
      if (!acc) return
      applyPickToAccumulator(acc, pick)
    })
  })

  const stats: TeamStats[] = []

  byId.forEach((acc) => {
    const totalDecisions = acc.wins + acc.losses
    const winRate = totalDecisions === 0 ? 0 : acc.wins / totalDecisions

    stats.push({
      team: acc.team,
      picks: acc.picks,
      wins: acc.wins,
      losses: acc.losses,
      winRate,
    })
  })

  // Sort by total picks (desc), then by team name for stability.
  stats.sort((a, b) => {
    if (b.picks !== a.picks) return b.picks - a.picks
    return a.team.name.localeCompare(b.team.name)
  })

  return stats
}

/**
 * Convenience helper that exposes team stats as a lookup map keyed by team ID.
 *
 * @param players - Optional custom players list; defaults to PLAYERS.
 * @returns Map from teamId to TeamStats.
 */
export const computeTeamStatsMap = (players: Player[] = PLAYERS): Map<string, TeamStats> => {
  const map = new Map<string, TeamStats>()
  const stats = computeTeamStats(players)
  stats.forEach((stat) => {
    map.set(stat.team.id, stat)
  })
  return map
}
