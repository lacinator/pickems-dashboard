/**
 * @file StandingsBar component.
 * Renders conference/division standings as compact rating bars for each team.
 */

import type { ConferenceId, StandingsTeam } from '../../data/standings'
import { STANDINGS_BY_CONFERENCE } from '../../data/standings'

/**
 * Groups a flat list of teams by division.
 */
function groupByDivision(teams: StandingsTeam[]): Array<{
  division: StandingsTeam['division']
  teams: StandingsTeam[]
}> {
  const map = new Map<StandingsTeam['division'], StandingsTeam[]>()

  teams.forEach((team) => {
    const existing = map.get(team.division)
    if (existing) {
      existing.push(team)
    } else {
      map.set(team.division, [team])
    }
  })

  return Array.from(map.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([division, divisionTeams]) => ({
      division,
      teams: [...divisionTeams].sort((a, b) => b.winPct - a.winPct),
    }))
}

/**
 * Computes a human-readable record string (e.g. "11-2" or "6-5-1").
 */
function formatRecord(team: StandingsTeam): string {
  if (team.ties > 0) {
    return `${team.wins}-${team.losses}-${team.ties}`
  }
  return `${team.wins}-${team.losses}`
}

/**
 * StandingsBar shows a league overview with rating bars by win percentage.
 */
export function StandingsBar() {
  const conferences: ConferenceId[] = ['AFC', 'NFC']

  return (
    <section className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/70 p-4 md:p-5">
      <header className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold text-slate-50 sm:text-base">
            League standings ratings
          </h2>
          <p className="text-[11px] text-slate-400 sm:text-xs">
            Higher bars indicate stronger records (.pct). Use this with the
            teams-left grid to find value picks.
          </p>
        </div>
      </header>

      <div className="mt-3 grid gap-4 md:grid-cols-2">
        {conferences.map((conference) => {
          const teams = STANDINGS_BY_CONFERENCE[conference]
          const divisions = groupByDivision(teams)

          return (
            <div
              key={conference}
              className="rounded-xl border border-slate-800 bg-slate-950/70 p-3"
            >
              <h3 className="text-xs font-semibold uppercase tracking-wide text-emerald-300">
                {conference} Standings
              </h3>
              <div className="mt-2 space-y-3">
                {divisions.map(({ division, teams: divisionTeams }) => (
                  <div key={division}>
                    <p className="text-[11px] font-semibold text-slate-300">
                      {conference} {division}
                    </p>
                    <div className="mt-1 space-y-1.5">
                      {divisionTeams.map((team) => {
                        const pctPercent = Math.round(team.winPct * 100)
                        const barWidth =
                          pctPercent === 0 || !Number.isFinite(pctPercent)
                            ? 0
                            : Math.max(pctPercent, 8)

                        return (
                          <div
                            key={team.id}
                            className="flex items-center gap-2"
                          >
                            <div className="w-28 text-[11px] text-slate-200">
                              <span className="font-semibold">
                                {team.id}{' '}
                              </span>
                              <span className="text-slate-400">
                                {formatRecord(team)}
                              </span>
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between text-[10px] text-slate-400">
                                <span>.{String(pctPercent).padStart(3, '0')}</span>
                                <span>{team.streak}</span>
                              </div>
                              <div className="mt-0.5 h-1.5 w-full rounded-full bg-slate-800">
                                <div
                                  className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-emerald-500 to-emerald-300"
                                  style={{ width: `${barWidth}%` }}
                                />
                              </div>
                            </div>
                            <div className="hidden w-20 text-right text-[10px] text-slate-500 sm:block">
                              PF {team.pointsFor} / PA {team.pointsAgainst}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default StandingsBar
