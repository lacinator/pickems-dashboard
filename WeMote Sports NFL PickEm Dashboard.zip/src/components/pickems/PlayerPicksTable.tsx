/**
 * @file PlayerPicksTable renders the main dashboard view:
 * each row is a player, each column is a week, cells show team logos.
 */

import type { Player } from '../../data/pickems'
import {
  getPlayerTotalPoints,
  TEAMS_BY_ID,
  WEEKS,
} from '../../data/pickems'
import { WeekCell } from './WeekCell'

/**
 * Props for the PlayerPicksTable component.
 */
export interface PlayerPicksTableProps {
  /** All players to display in the table. */
  players: Player[]
}

/**
 * Looks up a player's pick for a specific week, if any.
 */
function getPickForWeek(player: Player, week: number) {
  return player.weeklyPicks.find((p) => p.week === week)
}

/**
 * Table view where each row is a player and each column is a week (1–18).
 * Week cells show team logos and win/loss coloring.
 */
export function PlayerPicksTable({ players }: PlayerPicksTableProps) {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80 shadow-lg shadow-black/40">
      <div className="max-h-[32rem] overflow-auto">
        <table className="min-w-full border-collapse text-xs sm:text-sm">
          <thead className="sticky top-0 z-10 bg-slate-950/95 backdrop-blur">
            <tr>
              <th className="sticky left-0 z-20 border-b border-slate-800 bg-slate-950 px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-300 sm:text-xs">
                Player
              </th>
              <th className="sticky left-[120px] z-20 hidden border-b border-l border-slate-800 bg-slate-950 px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-300 sm:table-cell sm:text-xs">
                Total
              </th>
              <th className="border-b border-l border-slate-800 bg-slate-950 px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-300 sm:hidden">
                Pts
              </th>
              {WEEKS.map((week) => (
                <th
                  key={week}
                  className="border-b border-l border-slate-800 bg-slate-950 px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wide text-slate-300 sm:text-xs"
                >
                  W{week}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {players.map((player) => {
              const totalPoints = getPlayerTotalPoints(player)
              return (
                <tr
                  key={player.id}
                  className="even:bg-slate-950/70 odd:bg-slate-950/40 hover:bg-slate-900/70"
                >
                  <td className="sticky left-0 z-10 whitespace-nowrap border-b border-slate-800 bg-slate-950/90 px-3 py-2 text-sm font-medium text-slate-50 sm:text-base">
                    {player.name}
                  </td>
                  <td className="sticky left-[120px] hidden border-b border-l border-slate-800 bg-slate-950/90 px-3 py-2 text-right text-xs font-semibold text-emerald-300 sm:table-cell">
                    {totalPoints}
                  </td>
                  <td className="border-b border-l border-slate-800 px-3 py-2 text-right text-xs font-semibold text-emerald-300 sm:hidden">
                    {totalPoints}
                  </td>
                  {WEEKS.map((week) => {
                    const pick = getPickForWeek(player, week)
                    const team = pick ? TEAMS_BY_ID[pick.teamId] : undefined
                    return (
                      <WeekCell
                        key={week}
                        week={week}
                        pick={pick}
                        team={team}
                      />
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 bg-slate-950 px-3 py-2 text-[11px] text-slate-400 sm:px-4 sm:py-3 sm:text-xs">
        <div>
          <span className="font-semibold text-slate-200">Legend: </span>
          <span className="text-emerald-300">Green</span> = Win,{' '}
          <span className="text-rose-300">Red</span> = Loss,{' '}
          <span className="text-sky-300">Blue</span> = Pending game,{' '}
          <span className="text-slate-400">—</span> = No pick yet.
        </div>
        <div>
          Scoring: 
          <span className="text-slate-200">
            W1–4: 2 pts, W5–8: 4 pts, W9–13: 6 pts, W14–18: 8 pts. Ties =
            half of that week's points.
          </span>
        </div>
      </div>
    </div>
  )
}

export default PlayerPicksTable