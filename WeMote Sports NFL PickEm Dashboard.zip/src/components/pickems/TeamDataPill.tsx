/**
 * @file Compact data-visualization pill for an NFL team.
 * Renders basic stats (picks, win rate) as a small bar instead of a team logo.
 */

import type { Team } from '../../data/pickems'
import type { TeamStats } from '../../data/teamStats'

/**
 * Props for the TeamDataPill component.
 */
export interface TeamDataPillProps {
  /** Team metadata object. */
  team: Team
  /** Optional precomputed stats for this team. */
  stats?: TeamStats
}

/**
 * TeamDataPill displays a compact bar visualization for a team:
 * - Team code and name
 * - Total picks
 * - Win-rate bar with percentage label
 */
export function TeamDataPill({ team, stats }: TeamDataPillProps) {
  const picks = stats?.picks ?? 0
  const wins = stats?.wins ?? 0
  const losses = stats?.losses ?? 0
  const winRate = stats?.winRate ?? 0

  const winPercent = Math.round(winRate * 100)

  // Minimum visible width for non-zero percentages so tiny values are still visible.
  const barWidthPercent =
    winPercent === 0 || !Number.isFinite(winPercent) ? 0 : Math.max(winPercent, 6)

  return (
    <div
      className="flex flex-col gap-2 rounded-xl border border-slate-700 bg-slate-900/70 p-3 shadow-sm"
      aria-label={`Stats for ${team.name}: ${picks} picks, ${winPercent}% win rate`}
    >
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex flex-col">
          <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">
            {team.code}
          </span>
          <span className="text-sm font-medium text-slate-50">{team.name}</span>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-400">Total picks</div>
          <div className="text-sm font-semibold text-slate-50">{picks}</div>
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>
            W {wins} / L {losses}
          </span>
          <span className="font-medium text-emerald-400">{winPercent}% win</span>
        </div>
        <div className="h-2 w-full rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-emerald-500 to-emerald-300 transition-all"
            style={{ width: `${barWidthPercent}%` }}
          />
        </div>
      </div>
    </div>
  )
}

export default TeamDataPill
