/**
 * @file TeamsLeftPanel shows, for a selected player, which NFL teams are still available to pick.
 * Uses team logos with visual differentiation between used and remaining teams.
 */

import { useState } from 'react'
import type { Player } from '../../data/pickems'
import { getTeamsLeftForPlayer, getTeamsUsedByPlayer, TEAMS } from '../../data/pickems'

/**
 * Props for the TeamsLeftPanel component.
 */
export interface TeamsLeftPanelProps {
  /** All players participating in the pool. */
  players: Player[]
}

/**
 * Panel that lets you select a player and see which teams they have left to pick.
 */
export function TeamsLeftPanel({ players }: TeamsLeftPanelProps) {
  const [selectedId, setSelectedId] = useState(players[0]?.id ?? '')
  const selectedPlayer =
    players.find((p) => p.id === selectedId) ?? players[0]

  const usedTeams = selectedPlayer
    ? getTeamsUsedByPlayer(selectedPlayer)
    : new Set<string>()

  const remainingTeams = selectedPlayer
    ? getTeamsLeftForPlayer(selectedPlayer)
    : []

  return (
    <div className="flex flex-col gap-4 rounded-xl border border-slate-800 bg-slate-950/80 p-3 shadow-lg shadow-black/40 sm:flex-row sm:p-4">
      <aside className="w-full border-b border-slate-800 pb-3 sm:w-56 sm:border-b-0 sm:border-r sm:pb-0 sm:pr-3">
        <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
          Players
        </h2>
        <div className="flex max-h-72 flex-row gap-1 overflow-x-auto sm:flex-col sm:overflow-y-auto">
          {players.map((player) => {
            const active = player.id === selectedPlayer?.id
            return (
              <button
                key={player.id}
                type="button"
                onClick={() => setSelectedId(player.id)}
                className={[
                  'min-w-[6rem] rounded-full border px-3 py-1.5 text-left text-xs font-medium transition-colors sm:min-w-0',
                  active
                    ? 'border-emerald-400 bg-emerald-500/10 text-emerald-100'
                    : 'border-slate-700 bg-slate-900/70 text-slate-200 hover:border-emerald-400 hover:text-emerald-100',
                ].join(' ')}
              >
                {player.name}
              </button>
            )
          })}
        </div>
      </aside>

      <section className="flex-1">
        <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold text-slate-50 sm:text-base">
              Teams left for {selectedPlayer?.name}
            </h2>
            <p className="text-xs text-slate-400">
              {remainingTeams.length} of {TEAMS.length} teams still available.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-[11px] text-slate-400">
            <span className="inline-flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-emerald-500/40" />
              Remaining
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-slate-600/60" />
              Already used
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {TEAMS.map((team) => {
            const isUsed = usedTeams.has(team.id)
            const cardBg = isUsed
              ? 'bg-slate-800/70'
              : 'bg-emerald-600/10'
            const border = isUsed
              ? 'border-slate-600'
              : 'border-emerald-500/60'
            const text = isUsed ? 'text-slate-300' : 'text-emerald-100'
            const opacity = isUsed ? 'opacity-60' : 'opacity-100'

            return (
              <div
                key={team.id}
                className={[
                  'flex items-center gap-2 rounded-lg border px-2 py-1.5 transition-transform hover:-translate-y-0.5 hover:shadow',
                  cardBg,
                  border,
                  opacity,
                ].join(' ')}
              >
                <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full border border-white/30 bg-slate-950">
                  <img
                    src={team.logoSrc}
                    className="h-8 w-8 object-cover"
                    alt={`${team.name} logo`}
                  />
                </div>
                <div className="flex flex-col">
                  <span
                    className={[
                      'text-[11px] font-semibold leading-tight',
                      text,
                    ].join(' ')}
                  >
                    {team.code}
                  </span>
                  <span className="text-[10px] leading-tight text-slate-300">
                    {isUsed ? 'Used' : 'Available'}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </section>
    </div>
  )
}

export default TeamsLeftPanel