/**
 * @file WeekCell component.
 * Renders a single weekly pick cell with team logo and color-coding by result.
 * Pending games are highlighted in blue to distinguish them from wins/losses.
 */

import type { PickResult, Team, WeeklyPick } from '../../data/pickems'

/**
 * Props for a single weekly pick table cell.
 */
export interface WeekCellProps {
  /** Week number for this column (1–18). */
  week: number
  /** The player's pick for this week, if any. */
  pick?: WeeklyPick
  /** The team metadata for the picked team, if any. */
  team?: Team
}

/**
 * Computes Tailwind classes for a given pick result.
 * - W = green, L = red, T = amber, PENDING = blue, undefined = neutral slate.
 */
function getResultClasses(result?: PickResult): string {
  switch (result) {
    case 'W':
      return 'bg-emerald-950/80 border-emerald-500/70 text-emerald-100'
    case 'L':
      return 'bg-rose-950/80 border-rose-500/70 text-rose-100'
    case 'T':
      return 'bg-amber-950/80 border-amber-400/70 text-amber-100'
    case 'PENDING':
      // Pending games: highlighted in blue.
      return 'bg-sky-950/80 border-sky-500/70 text-sky-100'
    default:
      return 'bg-slate-950/60 border-slate-800 text-slate-300'
  }
}

/**
 * Renders a single table cell for a given player/week combination.
 * Shows team logo + code and applies background color based on the result.
 */
export function WeekCell({ pick, team }: WeekCellProps) {
  const hasPick = Boolean(pick && team)
  const resultClasses = getResultClasses(pick?.result)

  return (
    <td className="border-b border-l border-slate-800 px-1 py-1 text-center align-middle">
      {hasPick ? (
        <div
          className={[
            'mx-auto flex h-14 w-14 flex-col items-center justify-center gap-1 rounded-lg border text-[10px] shadow-sm sm:h-16 sm:w-16 sm:text-xs',
            resultClasses,
          ].join(' ')}
        >
          <div className="h-7 w-7 overflow-hidden rounded-full bg-slate-900/60 shadow-inner sm:h-8 sm:w-8">
            {/* Team logo (square, centered) */}
            <img
              src={team?.logoSrc}
              alt={team?.name}
              className="h-full w-full object-contain"
            />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-semibold tracking-tight">{team?.code}</span>
            {pick?.result === 'PENDING' ? (
              <span className="text-[9px] uppercase tracking-wide text-sky-200/90">
                Pending
              </span>
            ) : (
              <span className="text-[9px] uppercase tracking-wide text-slate-300/80">
                {pick?.result === 'W'
                  ? 'Win'
                  : pick?.result === 'L'
                    ? 'Loss'
                    : pick?.result === 'T'
                      ? 'Tie'
                      : ''}
              </span>
            )}
          </div>
        </div>
      ) : (
        <span className="text-[10px] text-slate-500 sm:text-xs">—</span>
      )}
    </td>
  )
}

export default WeekCell
