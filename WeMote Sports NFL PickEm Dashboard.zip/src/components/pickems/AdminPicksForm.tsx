/**
 * @file AdminPicksForm component.
 * Provides an in-page form for the commissioner/admin to add or update weekly picks.
 * This updates only in-memory state; production usage should wire this to a backend.
 */

import type { FormEvent } from 'react'
import { useState } from 'react'
import type { PickResult, Player } from '../../data/pickems'
import { TEAMS, WEEKS } from '../../data/pickems'

/**
 * Shape of the payload when the admin updates a pick.
 */
export interface AdminUpdatePickPayload {
  /** Player identifier to update. */
  playerId: string
  /** Week number (1–18). */
  week: number
  /** Team ID that is being picked. */
  teamId: string
  /** Result for the pick: win, loss, tie, or pending. */
  result: PickResult
}

/**
 * Props for the AdminPicksForm.
 */
export interface AdminPicksFormProps {
  /** All players currently in the pool. */
  players: Player[]
  /** Callback invoked when the admin adds or updates a pick. */
  onUpdatePlayerPick: (payload: AdminUpdatePickPayload) => void
}

/**
 * AdminPicksForm renders a compact control panel where the commissioner can:
 * - Select a player
 * - Choose a week
 * - Choose a team
 * - Set the result (W/L/T/PENDING)
 * and push the change into the parent component's state.
 */
export function AdminPicksForm({
  players,
  onUpdatePlayerPick,
}: AdminPicksFormProps) {
  const sortedPlayers = [...players].sort((a, b) => a.name.localeCompare(b.name))

  const [playerId, setPlayerId] = useState<string>(sortedPlayers[0]?.id ?? '')
  const [week, setWeek] = useState<number>(WEEKS[0] ?? 1)
  const [teamId, setTeamId] = useState<string>(TEAMS[0]?.id ?? '')
  const [result, setResult] = useState<PickResult>('W')
  const [status, setStatus] = useState<string | null>(null)

  /**
   * Handles form submission, dispatching the update to the parent.
   */
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault()
    if (!playerId || !teamId || !week) {
      setStatus('Please select a player, week, and team.')
      return
    }

    onUpdatePlayerPick({
      playerId,
      week,
      teamId,
      result,
    })

    setStatus('Pick saved for this week.')
    // Optional: keep selections so the admin can make small tweaks quickly.
  }

  return (
    <div className="rounded-xl border border-emerald-700/60 bg-slate-900/80 p-4 shadow-md shadow-emerald-900/40">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-emerald-100 sm:text-base">
            Commissioner tools
          </h3>
          <p className="mt-1 text-xs text-slate-400 sm:text-[13px]">
            Add or adjust weekly picks. Changes only affect this browser
            session and are not persisted to a server.
          </p>
        </div>
      </div>

      <form
        onSubmit={handleSubmit}
        className="grid gap-3 text-xs text-slate-100 sm:grid-cols-2 sm:text-sm"
      >
        <label className="flex flex-col gap-1">
          <span className="font-medium text-slate-300">Player</span>
          <select
            value={playerId}
            onChange={(e) => setPlayerId(e.target.value)}
            className="rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 outline-none ring-emerald-500 focus:ring sm:text-sm"
          >
            {sortedPlayers.map((player) => (
              <option key={player.id} value={player.id}>
                {player.name}
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col gap-1">
          <span className="font-medium text-slate-300">Week</span>
          <select
            value={week}
            onChange={(e) => setWeek(Number(e.target.value))}
            className="rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 outline-none ring-emerald-500 focus:ring sm:text-sm"
          >
            {WEEKS.map((w) => (
              <option key={w} value={w}>
                Week {w}
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col gap-1 sm:col-span-2">
          <span className="font-medium text-slate-300">Team</span>
          <select
            value={teamId}
            onChange={(e) => setTeamId(e.target.value)}
            className="rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 outline-none ring-emerald-500 focus:ring sm:text-sm"
          >
            {TEAMS.map((team) => (
              <option key={team.id} value={team.id}>
                {team.code} — {team.name}
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col gap-1">
          <span className="font-medium text-slate-300">Result</span>
          <select
            value={result}
            onChange={(e) => setResult(e.target.value as PickResult)}
            className="rounded-md border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-slate-100 outline-none ring-emerald-500 focus:ring sm:text-sm"
          >
            <option value="W">Win (full points)</option>
            <option value="L">Loss (0 points)</option>
            <option value="T">Tie (half points)</option>
            <option value="PENDING">Pending / not played</option>
          </select>
        </label>

        <div className="flex items-end justify-between gap-2 sm:col-span-2">
          <button
            type="submit"
            className="inline-flex items-center justify-center rounded-md bg-emerald-500 px-3 py-1.5 text-xs font-semibold text-slate-950 shadow-sm shadow-emerald-900 transition hover:bg-emerald-400 sm:text-sm"
          >
            Save pick
          </button>
          {status && (
            <p className="text-[11px] text-emerald-300 sm:text-xs">{status}</p>
          )}
        </div>
      </form>
    </div>
  )
}

export default AdminPicksForm
