/**
 * @file Shared page layout for the NFL Pick Em's dashboard.
 * Provides the header, navigation, and responsive content container.
 */

import type { ReactNode } from 'react'
import { Link, useLocation } from 'react-router'

/**
 * Props for the PageLayout component.
 */
interface PageLayoutProps {
  /** Main content for the current route. */
  children: ReactNode
}

/**
 * High-level shell layout with title, subtitle, and page navigation.
 */
export function PageLayout({ children }: PageLayoutProps) {
  const location = useLocation()

  const navItems = [
    { to: '/', label: 'Dashboard' },
    { to: '/teams-left', label: 'Teams Left' },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 pb-10 pt-6 sm:px-6 lg:px-8">
        <header className="flex flex-col gap-4 border-b border-slate-800 pb-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
              WeMote Sports TA NFL Pick Em's Challenge
            </h1>
            <p className="mt-1 text-sm text-slate-300">
              Commission of Classy Football Operations
            </p>
            <p className="mt-3 max-w-2xl text-xs text-slate-400 sm:text-sm">
              Each week, pick one team to win. No repeats all season. Points
              scale up over the year: 2 pts (Weeks 1–4), 4 pts (5–8), 6 pts
              (9–13), 8 pts (14–18). Ties are worth half of that week's
              points.
            </p>
          </div>
          <nav className="flex gap-2">
            {navItems.map((item) => {
              const active = location.pathname === item.to
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={[
                    'inline-flex items-center rounded-full border px-4 py-1.5 text-sm font-medium transition-colors',
                    active
                      ? 'border-emerald-400 bg-emerald-500/10 text-emerald-100'
                      : 'border-slate-700 bg-slate-900/60 text-slate-200 hover:border-emerald-400 hover:text-emerald-100',
                  ].join(' ')}
                >
                  {item.label}
                </Link>
              )
            })}
          </nav>
        </header>

        <main>{children}</main>
      </div>
    </div>
  )
}

export default PageLayout