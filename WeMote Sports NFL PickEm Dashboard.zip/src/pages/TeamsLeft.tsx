/**
 * @file Teams-left page.
 * Allows selecting a player and visualizes which teams they can still pick,
 * using data visualizations instead of team logos.
 */

import { useMemo, useState } from 'react'
import { Link } from 'react-router'
import {
  getTeamsLeftForPlayer,
  getPlayersSortedByPoints,
  PLAYERS,
  type Player,
} from '../data/pickems'
import { computeTeamStatsMap } from '../data/teamStats'
import { TeamDataPill } from '../components/pickems/TeamDataPill'
import { StandingsBar } from '../components/standings/StandingsBar'

/**
 * TeamsLeftPage renders:
 * - A player selector sidebar
 * - A grid of remaining teams for the selected player,
 *   where each tile is a data-visualization pill.
 * - A league standings bar showing team rating bars by record.
 */
export default function TeamsLeftPage() {
  const playersSorted = useMemo(() => getPlayersSortedByPoints(PLAYERS), [])
  const [selectedPlayerId, setSelectedPlayerId] = useState(
    playersSorted[0]?.id ?? '',
  )

  // Precompute team stats once for all players.
  const statsMap = useMemo(() => computeTeamStatsMap(PLAYERS), [])

  const selectedPlayer: Player | undefined = playersSorted.find(
    (p) => p.id === selectedPlayerId,
  )

  const teamsLeft = selectedPlayer ? getTeamsLeftForPlayer(selectedPlayer) : []

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <main className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 lg:px-8">
        <header className="flex flex-col items-start justify-between gap-4 border-b border-slate-800 pb-4 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              Teams Left by Player
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Select a player to see which teams they can still pick. Each team
              is shown with a small performance chart instead of its logo.
            </p>
          </div>
          <nav className="flex gap-3">
            <Link
              to="/"
              className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-emerald-500/60 hover:text-emerald-300"
            >
              ⟵ Back to Leaderboard
            </Link>
          </nav>
        </header>

        <div className="flex flex-col gap-6 md:flex-row">
          {/* Player selector sidebar */}
          <aside className="w-full rounded-2xl border border-slate-800 bg-slate-900/70 p-4 md:w-64">
            <h2 className="mb-3 text-sm font-semibold text-slate-200">
              Players
            </h2>
            <div className="flex max-h-[480px] flex-col gap-1 overflow-y-auto pr-1 text-sm">
              {playersSorted.map((player) => {
                const isActive = player.id === selectedPlayerId
                return (
                  <button
                    key={player.id}
                    type="button"
                    onClick={() => setSelectedPlayerId(player.id)}
                    className={`flex items-center justify-between rounded-lg px-3 py-2 text-left transition ${
                      isActive
                        ? 'bg-emerald-500/15 text-emerald-200 ring-1 ring-emerald-400/70'
                        : 'bg-transparent text-slate-200 hover:bg-slate-800/80'
                    }`}
                  >
                    <span>{player.name}</span>
                  </button>
                )
              })}
            </div>
          </aside>

          {/* Teams-left grid for the selected player */}
          <section className="flex-1 rounded-2xl border border-slate-800 bg-slate-900/60 p-4 md:p-6">
            {selectedPlayer ? (
              <>
                <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
                  <div>
                    <h2 className="text-lg font-semibold text-slate-50 sm:text-xl">
                      Teams {selectedPlayer.name} can still pick
                    </h2>
                    <p className="text-xs text-slate-400">
                      Sorted alphabetically. Bars show how successful each team
                      has been overall in the pool.
                    </p>
                  </div>
                  <div className="text-xs text-slate-400">
                    Total teams left:{' '}
                    <span className="font-semibold text-emerald-300">
                      {teamsLeft.length}
                    </span>
                  </div>
                </div>

                {teamsLeft.length === 0 ? (
                  <p className="text-sm text-slate-400">
                    This player has already used every team at least once.
                  </p>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {teamsLeft
                      .slice()
                      .sort((a, b) => a.name.localeCompare(b.name))
                      .map((team) => {
                        const stats = statsMap.get(team.id)
                        return (
                          <TeamDataPill key={team.id} team={team} stats={stats} />
                        )
                      })}
                  </div>
                )}
              </>
            ) : (
              <p className="text-sm text-slate-400">
                Select a player from the left-hand list to view their remaining
                teams.
              </p>
            )}
          </section>
        </div>

        {/* League standings rating bar */}
        <StandingsBar />
      </main>
    </div>
  )
}
