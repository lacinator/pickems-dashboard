/**
 * @file Home dashboard page.
 * Renders a weekly picks dashboard where each player has one row
 * and each week is a column showing the picked team's logo.
 * Also exposes a commissioner-only form to adjust weekly picks in memory.
 */

import { useState, type FormEvent } from 'react'
import { Link } from 'react-router'
import type { PickResult, Player } from '../data/pickems'
import {
  PLAYERS,
  getPlayersSortedByPoints,
  getPlayerTotalPoints,
} from '../data/pickems'
import PlayerPicksTable from '../components/pickems/PlayerPicksTable'
import AdminPicksForm from '../components/pickems/AdminPicksForm'
import type { AdminUpdatePickPayload } from '../components/pickems/AdminPicksForm'

/**
 * Constant ID for the only admin user allowed to edit picks.
 * This is a front-end only gate and should be backed by real auth in production.
 */
const ADMIN_ID = 'User_Shaughn'

/**
 * HomePage shows the main Pick 'Em dashboard:
 * - Leaderboard summary
 * - Weekly grid of picks using team logos for each player
 * - Late-season matchup schedule (Week 17 & 18)
 * - Commissioner tools to add or adjust weekly picks (local only, admin-gated).
 */
export default function HomePage() {
  const [players, setPlayers] = useState<Player[]>(() => PLAYERS)
  const [showAdmin, setShowAdmin] = useState(false)

  // Simple client-side admin gate.
  const [isAdmin, setIsAdmin] = useState(false)
  const [adminIdInput, setAdminIdInput] = useState('')
  const [adminError, setAdminError] = useState<string | null>(null)

  const playersSorted = getPlayersSortedByPoints(players)
  const topFive = playersSorted.slice(0, 5)
  const topPlayer = topFive[0]
  const topPlayerPoints = topPlayer ? getPlayerTotalPoints(topPlayer) : 0

  /**
   * Applies an admin-submitted pick update to the local players state.
   * If a pick for that week already exists, it is replaced; otherwise, it is added.
   */
  const handleUpdatePlayerPick = ({
    playerId,
    week,
    teamId,
    result,
  }: AdminUpdatePickPayload) => {
    setPlayers((prev) =>
      prev.map((player) => {
        if (player.id !== playerId) return player

        const existingIndex = player.weeklyPicks.findIndex(
          (pick) => pick.week === week,
        )

        const updatedPick = { week, teamId, result: result as PickResult }

        const updatedWeeklyPicks =
          existingIndex >= 0
            ? player.weeklyPicks.map((pick, index) =>
                index === existingIndex ? updatedPick : pick,
              )
            : [...player.weeklyPicks, updatedPick].sort(
                (a, b) => a.week - b.week,
              )

        return {
          ...player,
          weeklyPicks: updatedWeeklyPicks,
        }
      }),
    )
  }

  /**
   * Handles the inline admin sign-in form submission.
   * Only the exact ADMIN_ID value unlocks admin mode.
   */
  const handleAdminSignIn = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const trimmed = adminIdInput.trim()
    if (trimmed === ADMIN_ID) {
      setIsAdmin(true)
      setAdminError(null)
      // Keep showAdmin false until the admin explicitly opens the form.
    } else {
      setIsAdmin(false)
      setAdminError('Invalid admin ID. Only the commissioner can edit picks.')
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <main className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 lg:px-8">
        {/* Header & navigation */}
        <header className="flex flex-col items-start justify-between gap-4 border-b border-slate-800 pb-4 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              WeMote Sports TA — NFL Pick Em's Weekly Dashboard
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Each row is a player and each column is a week. Cells show the
              team logo and result coloring for that pick.
            </p>
          </div>
          <nav className="flex gap-3">
            <Link
              to="/"
              className="rounded-lg border border-emerald-500/60 bg-emerald-500/10 px-4 py-2 text-sm font-medium text-emerald-300 shadow-sm transition hover:bg-emerald-500/20"
            >
              Weekly Dashboard
            </Link>
            <Link
              to="/teams-left"
              className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-emerald-500/60 hover:text-emerald-300"
            >
              Teams Left by Player
            </Link>
          </nav>
        </header>

        {/* High-level stats row */}
        <section className="grid gap-4 md:grid-cols-2">
          {/* Left column: leaderboard stacked over legend */}
          <div className="flex flex-col gap-4">
            {/* Leaderboard (top 5) */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
                Leaderboard (Top 5)
              </p>
              {topFive.length > 0 ? (
                <ul className="mt-2 space-y-1.5 text-xs sm:text-sm">
                  {topFive.map((player, index) => {
                    const points = getPlayerTotalPoints(player)
                    const behind = topPlayerPoints - points
                    const isLeader = index === 0

                    return (
                      <li
                        key={player.id}
                        className="flex items-baseline justify-between gap-2"
                      >
                        <div className="flex items-baseline gap-2">
                          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-800 text-[10px] font-semibold text-slate-200">
                            {index + 1}
                          </span>
                          <span className="font-medium text-slate-50">
                            {player.name}
                          </span>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-semibold text-emerald-300 sm:text-sm">
                            {points} pts
                          </p>
                          <p className="text-[10px] text-slate-400 sm:text-xs">
                            {isLeader ? 'Leader' : `${behind} pts back`}
                          </p>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              ) : (
                <p className="mt-2 text-sm text-slate-400">No players yet.</p>
              )}
              <p className="mt-2 text-[10px] text-slate-500 sm:text-xs">
                Rankings are based on total points; ties break alphabetically by
                name.
              </p>
            </div>

            {/* Legend & scoring - compact, stacked under leaderboard */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-[11px] sm:text-xs">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                Legend & scoring
              </p>
              <div className="mt-2 space-y-1.5 text-slate-300">
                <p>
                  <span className="text-emerald-300">Green</span> = win,{' '}
                  <span className="text-rose-300">Red</span> = loss,{' '}
                  <span className="text-sky-300">Blue</span> = pending game,{' '}
                  <span className="text-slate-400">—</span> = no pick yet.
                </p>
                <p className="text-slate-400">
                  Scoring bands: 
                  <span className="text-slate-200">
                    W1–4: 2 pts, W5–8: 4 pts, W9–13: 6 pts, W14–18: 8 pts.
                  </span>
                </p>
                <p className="text-slate-400">
                  Ties earn half of that week's points.
                </p>
              </div>
              <a
                href="https://forms.office.com/pages/responsepage.aspx?id=-SY1T9aXLUGTOk4wpzEQ9P6WUtjEBZNKsTteSvVUCuVURDMzUkEzQVhDV0NDMUtMT0tRQlE1OTVMQi4u&route=shorturl"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center justify-center rounded-full border border-emerald-400 bg-emerald-500/10 px-4 py-1.5 text-xs font-semibold text-emerald-100 shadow-sm transition hover:bg-emerald-500/20"
              >
                Enter Pick Here
              </a>
            </div>
          </div>

          {/* Right column: late-season matchups widget (Weeks 17 & 18) */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-[11px] sm:text-xs">
            <p className="text-[10px] font-semibold uppercase tracking-wide text-emerald-300">
              Week 17 & Week 18 Matchups
            </p>
            <p className="mt-1 text-[10px] text-slate-400">
              Key games for the final two regular-season weeks (times as
              listed).
            </p>

            {/* Week 17 schedule – only tonight's Monday night game */}
            <div className="mt-3 space-y-2.5">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-300">
                Week 17 · Mon, Dec 29, 2025
              </p>

              <div>
                <p className="font-semibold text-slate-200">
                  Monday Night Football · Mon, Dec 29
                </p>
                <p className="text-slate-300">
                  Los Angeles Rams @ Atlanta Falcons — 6:15 PM MT — ESPN
                </p>
              </div>
            </div>

            {/* Week 18 schedule */}
            <div className="mt-4 space-y-2.5 border-t border-slate-800 pt-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-300">
                Week 18 · Jan 3–4, 2026 (Final Regular Season Week)
              </p>

              <div>
                <p className="font-semibold text-slate-200">
                  Sat, Jan 3 — Flexed Games
                </p>
                <p className="text-slate-300">
                  Two games will be flexed into 4:30 PM ET and 8:00 PM ET slots
                  on ESPN/ABC (teams TBD based on playoff stakes).
                </p>
              </div>

              <div>
                <p className="font-semibold text-slate-200">
                  Sun, Jan 4 — All Other Games (Times TBD)
                </p>
                <ul className="mt-0.5 space-y-0.5 text-slate-300">
                  <li>New Orleans Saints @ Atlanta Falcons</li>
                  <li>New York Jets @ Buffalo Bills</li>
                  <li>Detroit Lions @ Chicago Bears</li>
                  <li>Cleveland Browns @ Cincinnati Bengals</li>
                  <li>Los Angeles Chargers @ Denver Broncos</li>
                  <li>Indianapolis Colts @ Houston Texans</li>
                  <li>Tennessee Titans @ Jacksonville Jaguars</li>
                  <li>Arizona Cardinals @ Los Angeles Rams</li>
                  <li>Kansas City Chiefs @ Las Vegas Raiders</li>
                  <li>Green Bay Packers @ Minnesota Vikings</li>
                  <li>Miami Dolphins @ New England Patriots</li>
                  <li>Dallas Cowboys @ New York Giants</li>
                  <li>Washington Commanders @ Philadelphia Eagles</li>
                  <li>Baltimore Ravens @ Pittsburgh Steelers</li>
                  <li>Seattle Seahawks @ San Francisco 49ers</li>
                  <li>Carolina Panthers @ Tampa Bay Buccaneers</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Weekly picks table with team logos */}
        <section className="space-y-3">
          <h2 className="text-lg font-semibold text-slate-50 sm:text-xl">
            Weekly Picks by Player
          </h2>
          <PlayerPicksTable players={playersSorted} />
        </section>

        {/* Admin / commissioner tools (view-only for non-admins) */}
        <section className="space-y-3">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <h2 className="text-sm font-semibold text-slate-200 sm:text-base">
              Commissioner tools
            </h2>

            {isAdmin ? (
              <button
                type="button"
                onClick={() => setShowAdmin((prev) => !prev)}
                className="inline-flex items-center rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs font-medium text-slate-200 shadow-sm transition hover:border-emerald-400 hover:text-emerald-100 sm:text-sm"
              >
                {showAdmin ? 'Hide admin form' : 'Show admin form'}
              </button>
            ) : (
              <form
                onSubmit={handleAdminSignIn}
                className="flex flex-wrap items-center gap-2 text-xs sm:text-sm"
              >
                <label className="flex items-center gap-1 text-slate-300">
                  <span className="text-[11px] sm:text-xs">Admin ID</span>
                  <input
                    value={adminIdInput}
                    onChange={(e) => setAdminIdInput(e.target.value)}
                    placeholder="Enter admin ID"
                    className="h-7 rounded-md border border-slate-700 bg-slate-950 px-2 text-[11px] text-slate-100 outline-none ring-emerald-500 focus:ring sm:h-8 sm:text-xs"
                  />
                </label>
                <button
                  type="submit"
                  className="inline-flex h-7 items-center justify-center rounded-md bg-emerald-500 px-3 text-[11px] font-semibold text-slate-950 shadow-sm shadow-emerald-900 transition hover:bg-emerald-400 sm:h-8 sm:text-xs"
                >
                  Sign in
                </button>
              </form>
            )}
          </div>

          {!isAdmin && (
            <p className="text-[11px] text-slate-400 sm:text-xs">
              View-only mode. All picks and standings are visible, but only the
              commissioner can edit picks. Admin ID is restricted to the
              creator.
            </p>
          )}
          {adminError && !isAdmin && (
            <p className="text-[11px] text-rose-300 sm:text-xs">{adminError}</p>
          )}

          {isAdmin && showAdmin && (
            <AdminPicksForm
              players={players}
              onUpdatePlayerPick={handleUpdatePlayerPick}
            />
          )}
        </section>
      </main>
    </div>
  )
}
