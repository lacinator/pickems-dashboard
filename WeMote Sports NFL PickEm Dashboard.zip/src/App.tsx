/**
 * @file Root application component.
 * Wires up routing between the dashboard and teams-left views.
 */

import { HashRouter, Route, Routes } from 'react-router'
import HomePage from './pages/Home'
import TeamsLeftPage from './pages/TeamsLeft'

/**
 * App configures top-level routes using a hash-based router.
 */
export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/teams-left" element={<TeamsLeftPage />} />
      </Routes>
    </HashRouter>
  )
}